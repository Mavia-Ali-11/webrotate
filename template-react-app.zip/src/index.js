import React, { useEffect } from 'react';
import { render } from 'react-dom';
import WR360 from '@webrotate360/imagerotator';
import './style.css';
// all.css packs all themes and relies on theme info in published xml. Import individual theme instead if needed, e.g (thin.css or round.css, etc).
import '@webrotate360/imagerotator/build/css/all.css';

const Car = () => {

    useEffect(() => {
        const viewer = WR360.ImageRotator.Create('webrotate360');

        viewer.licenseCode = 'your-license-code';
        viewer.settings.configFileURL = '/example/car.xml';
        viewer.settings.graphicsPath = '/graphics';
        viewer.settings.alt = 'Your alt image description';
        viewer.settings.responsiveBaseWidth = 800;
        viewer.settings.responsiveMinHeight = 300;

        viewer.settings.apiReadyCallback = (api, isFullScreen) => {
            // let viewerApi = api;
            const hotspotElements = document.querySelectorAll('.hotspot_indicator');
            hotspotElements.forEach(element => {
              element.addEventListener('touchstart', () => {
                document.getElementById("wr360DynamicSpot_left-side_webrotate360").style.backgroundImage = `url('${window.location.origin}/graphics/circ-cross-thin-green.svg')`;
              });
            });
            // this.viewerApi.images.onDrag(event => {
            //     console.log(`${event.action}; current image index = ${this.viewerApi.images.getCurrentImageIndex()}`);
            // });
        }

        viewer.runImageRotator();
    }, [])


    return (
        <span onClick={(e) => e.target.style.backgroundImage = `url('${window.location.origin}/graphics/circ-cross-thin-green.svg')`}>
            <div className="viewerContainer">
                <div id="webrotate360" />
            </div>
        </span>
    );
}

render(<Car />, document.getElementById('root'));
